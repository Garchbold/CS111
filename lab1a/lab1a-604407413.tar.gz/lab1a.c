#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <getopt.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>


struct termios original_attr;
int terminal_to_shell[2];
int shell_to_terminal[2];
char newline[2];
pid_t pid;

void reset_input_mode (void)
{
  tcsetattr (STDIN_FILENO, TCSANOW, &original_attr);
}

void set_input_mode (void)
{
  struct termios temp_attr;
 
  //check if the file descriptor is set to the terminal
  if (!isatty (STDIN_FILENO))
    {
      fprintf (stderr, "Not a terminal.\n");
      exit (EXIT_FAILURE);
    }

  // Save the terminal attributes
  tcgetattr (STDIN_FILENO, &original_attr);
  atexit (reset_input_mode);

  // Set the terminal
  tcgetattr (STDIN_FILENO, &temp_attr);
  temp_attr.c_lflag &= ~(ICANON|ECHO); /* Clear ICANON and ECHO. */
  temp_attr.c_cc[VMIN] = 1;
  temp_attr.c_cc[VTIME] = 0;
  tcsetattr (STDIN_FILENO, TCSAFLUSH, &temp_attr);
}


void print_status(){

  int status;
  pid_t RC = waitpid(pid, &status, 0);
  if (RC > 0){
    {
      if (WIFEXITED(status))
	printf("Child exited with RC=%d\n", WEXITSTATUS(status));
      else
	printf("Child process aborted abnormally\n");
    }
  }
}

void signal_handler(int signum){
  if(signum == SIGINT)
    kill(pid, SIGINT);
  
  if(signum == SIGPIPE)
    {
      print_status();
      reset_input_mode();
      exit(1);
    }
  if(signum == SIGHUP)
    {
      print_status();
      exit(1);
    }
}


void *  terminal_write(){
  //read input from the keyboard, echo it to stdout, and forward it to the shell
  char buffer;
  int bufsize;
  
  while(1){

    bufsize = read(STDIN_FILENO, &buffer, 1);

    
    if(bufsize == -1){
      fprintf(stderr, "Error reading input in twrite");
      break;
    }

    //EOF
    if(buffer == 0X04){
      reset_input_mode();
      kill(pid, SIGHUP);
      //      print_status();
      close(terminal_to_shell[1]);
      close(shell_to_terminal[0]);
      print_status();
      exit(0);
    }

    //CR
    if (buffer == 0x0d){
      write(1, &newline, 2);
      write(terminal_to_shell[1], &newline[1], 1);
      continue;
    }
    
    //LF
    if (buffer == 0x0a){
      write(1, &newline, 2);
      write(terminal_to_shell[1], &newline[1], 1);
      continue;
     }

    write(1, &buffer, 1);
    write(terminal_to_shell[1], &buffer, 1);
  }
}


int main(int argc, char** argv){

  char buffer;
  int bufsize;
  static int shell_flag = 0;
  int c = 0;

  newline[0] = 0x0d;
  newline[1] = 0x0a;

  set_input_mode();

  while(1){
  static struct option long_options[] =
    {
       {"shell", no_argument, &shell_flag, 1},
       {0, 0, 0, 0,}
    };

  int option_index = 0;
  c = getopt_long(argc, argv,"", long_options, &option_index);

  if(c == -1)
    break;
  }

  pipe(terminal_to_shell);
  pipe(shell_to_terminal);
  
  if (shell_flag == 1){

    pid = fork();

    if(pid == -1){
      fprintf(stderr, "Failed to fork processes.");
      exit(-1);
    }
    else if (pid == 0){
      close(terminal_to_shell[1]);
      close(shell_to_terminal[0]);
      
      dup2(terminal_to_shell[0], 0);
      dup2(shell_to_terminal[1], 1);
      dup2(shell_to_terminal[1], 2);
      
      execl("/bin/bash","/bin/bash",  NULL);

    }
    
    else{

      signal(SIGPIPE, signal_handler);
      signal(SIGINT, signal_handler);
      close(terminal_to_shell[0]);
      close(shell_to_terminal[1]);

      pthread_t terminal_write_thread;
      int thread_check = 0;

      thread_check = pthread_create(&terminal_write_thread, NULL, &terminal_write, NULL);
      if(thread_check < 0)
	fprintf(stderr, "Failed to create thread");
    
      char read_buffer;
      int read_bufsize;

      while(1){

	read_bufsize = read(shell_to_terminal[0], &read_buffer, 1);
	  
	if(read_buffer == 0X04){
	  reset_input_mode();
	  close(terminal_to_shell[1]);
	  close(shell_to_terminal[0]);
	  print_status();
	  exit(1);

	}

	write(1, &read_buffer, 1);
      }
    }
  }

 else{

   while (1)
    {

      bufsize = read(STDIN_FILENO, &buffer, 1);

      if(bufsize == -1){
	fprintf(stderr, "Error reading input\n");
	break;
      }

	if(buffer == 0X04){
	  reset_input_mode();
	  exit(1);
	}

	if (buffer == 0x0a || buffer == 0x0d){
     	  write(1, &newline, 2);
	  continue;
	}
	
	write(1, &buffer, 1);

    }
  reset_input_mode();
  return EXIT_SUCCESS;

 }
}
